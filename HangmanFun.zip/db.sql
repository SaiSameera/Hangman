
CREATE SCHEMA `hangman` ;

CREATE TABLE `hangman`.`stats` (
  `Highscore_id` INT NOT NULL AUTO_INCREMENT,
  `Name` VARCHAR(45) NOT NULL,
  `streak` INT NULL,
  PRIMARY KEY (`Highscore_id`));

CREATE TABLE `hangman`.`words` (
  `Word_id` INT NOT NULL AUTO_INCREMENT,
  `Word_Value` VARCHAR(80) NOT NULL,
  PRIMARY KEY (`Word_id`));

INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('1', 'DATABASE');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('2', 'Java');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('3', 'Javascript');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('4', 'Jboss');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('5', 'Programming Language');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('6', 'database');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('7', 'ajax');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('8', 'bigdata');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('9', 'testing');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('10', 'SQL scripts');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('11', 'apachetomcat');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('12', 'Oracle');
INSERT INTO `hangman`.`words` (`Word_id`, `Word_Value`) VALUES ('13', 'google');



  
  
