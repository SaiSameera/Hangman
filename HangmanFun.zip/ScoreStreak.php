<html>
<?php
include('database.php');
$result=mysql_query("SELECT * FROM stats;");
$row=mysql_fetch_array($result);
$c=mysql_num_rows($result);
?>
<head>
	<title>Hangman Fun</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="form">
		<h2 align="center">Hangman Fun!!!</h2>
		
		<a href=".">Main Menu</a>
		<?php
		if($c<=0)
		{
			echo "<p style='color:red' align='center'>No records so far. You be the first person to create record. Lets Go.</p>";
		}
		else
		{
		?>
		<table width="60%" align="center" border="1">
		<tr>
			<td align="center"><b>Name</b></td>
			<td align="center"><b>Streak</b></td>
		</tr>
		<?php
		do
		{
			$Name=$row[1];
			$Streak=$row[2];
			echo "<tr><td align='center'>$Name</td><td align='center'>$Streak</td></tr>";
		}while($row=mysql_fetch_array($result));
		?>
		</table>
		<?php
		}
		?>
	</div>
</body>
</html>



