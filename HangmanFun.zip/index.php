<html>
<head>
	<title>Hangman Fun</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="form">
		<h2 align="center">Hangman Fun!!!</h2>
		<hr/>
		<h1 align="center">
			<a href="SinglePlayer.php">1 Player Mode</a>
		</h1>
		<h1 align="center">
			<a href="TwoPlayer.php">2 Players Mode</a>
		</h1>
		<h1 align="center">
			<a href="ScoreStreak.php">Highscore Stats</a>
		</h1>
	</div>
</body>
</html>