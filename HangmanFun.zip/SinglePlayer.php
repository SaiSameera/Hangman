<html>
<?php
include('database.php');
$result=mysql_query("SELECT * FROM words ORDER BY RAND() LIMIT 1;");
$row=mysql_fetch_array($result);
$c=mysql_num_rows($result);
?>
<head>
	<title>Hangman Fun</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script>
	var mysteryword = "<?php echo $row[1]; ?>";
	//var mysteryword = "google";
	console.log(mysteryword);
	
	var enteredWord= [];
	var DASH = "_";
	var SPACE = "&nbsp;";
	var numChancesUsed = 0;

	function generateDashes() {
		for(i=0;i<mysteryword.length;i++){
			if(mysteryword[i] === " ") {
				enteredWord.push(" ");
			} else {
				enteredWord.push(DASH);
			}
		}
		displayEnteredWord();
	}
	
	function updateImage(index) {
		document.getElementById("hangManImg").src= "images/hang"+index+".png";
	}
	
	function enteredLetter(value) {
		var indices = [];
		for(var i=0; i<mysteryword.length;i++) {
			if (mysteryword[i].toLowerCase() === value.toLowerCase()) indices.push(i);
		}
		//console.log(indices);
		recalculateEnteredWordAndShow(value, indices);
		
		document.getElementById("dyna_"+value).innerHTML = value;
	}
	
	function recalculateEnteredWordAndShow(value, indices) {
		//console.log(numChancesUsed);
		if(numChancesUsed < 5) {
			if(indices.length == 0) {
				++numChancesUsed
				document.getElementById("dynaChancesLeft").innerHTML = (6-numChancesUsed);
				updateImage(numChancesUsed);
			} else {
				console.log("update guess word");
				for(var i=0; i<indices.length;i++) {
					enteredWord[indices[i]] = value;
				}
				displayEnteredWord();
				checkEquals();
			}
			//console.log(enteredWord);
		} else {
			var r = confirm("Sorry!!! You Lost. The word is "+ mysteryword.toUpperCase() +"\nPress OK to play again. Cancel to goto homepage");
			if (r == true) {
				location.reload();
			} else {
				location.href="./index.php";
			}
		}
	}

	function displayEnteredWord() {
		var output="";
		for(i=0;i<enteredWord.length;i++) {
			if(enteredWord[i] === " ") {
				output += (SPACE+SPACE);	
			} else {
				output += (enteredWord[i]+SPACE);	
			}
		}
		document.getElementById("dynaGuessWord").innerHTML=output;
	}
	
	function checkEquals() {
		var value="";
		for(i=0;i<enteredWord.length;i++) {
			value+=enteredWord[i];
		}
		if(value.toLowerCase() === mysteryword.toLowerCase()) {
			var r = confirm("Congratulations!!! You Won. \nPress OK to play again. Cancel goto homepage");
			if (r == true) {
				
				location.reload();
			} else {
				location.href="./index.php";
			}
		}
	}
	</script>
</head>
<body>

<div class="form">
	<table width="90%" height="70%" border='1' align="center">
		<tr>
			<td align="center">
				<div><div id="dynaGuessWord" style="font-size:40px;">Guess Word Here</div></div>
			</td>
			<td rowspan="2" align="center"><img id="hangManImg" src="images/hang0.png" /></td>
		</tr>
		<tr>
			<td align="center">
				<div id="dynaGuessWord">
					<?php
						$a=range("A","Z");
					?>
					 <?php foreach ( $a as $char ) : ?>
						<span  id="dyna_<?=$char?>"><a href="javascript:enteredLetter('<?=$char?>')"><?=$char?></a></span>
					 <?php endforeach; ?>
				</div>
				<div style="color:grey;font-size:10px">Chances Left: <span id="dynaChancesLeft">6</span></div>
			</td>
		</tr>
	</table>
	
	<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
</div>
<script>
	generateDashes();
</script>
</body>
</html>