<?php
$con=mysql_connect("localhost","root","root");
$db=mysql_select_db("hangman",$con);
?>