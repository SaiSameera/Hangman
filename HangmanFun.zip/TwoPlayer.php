
<html>
<head>
	<title>Hangman Fun</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="form">
		<form method="POST" action="TwoPlayerStart.php">
			<table align="center">
				<tr>
					<td>Player 1 Enter Word</td>
					<td><input type="password" name="mysteryword" id="mysteryword" /></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" value="Submit" /></td>
				</tr>
			</table>	
		</form>
	</div>
</body>

</html>